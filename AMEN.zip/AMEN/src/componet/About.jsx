import React from 'react'
import './About.css'
const about = () => {

  function handleSubmit(event) {
    event.preventDefault(); // Prevent the default form submission behavior

    const formData = {
      name: event.target.name.value,
      phone: event.target.phone.value,
      email: event.target.email.value,
    };

    console.log('Form Data:', formData);

    // Add your form submission logic here (e.g., send data to the server)
  }
  return (
    <div>
 <form onSubmit={handleSubmit}>
        <div className="form-group">
            <label htmlFor="name">Name:</label>
            <input type="text" id="name" name="name" required />
        </div>

        <div className="form-group">
            <label htmlFor="phone">Phone Number:</label>
            <input type="tel" id="phone" name="phone" required />
        </div>

        <div className="form-group">
            <label htmlFor="email">Email:</label>
            <input type="email" id="email" name="email" required />
        </div>

        <button type="submit">Request Call Back</button>
    </form>
    </div>
  )
}

export default about
