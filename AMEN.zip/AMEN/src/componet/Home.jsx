// import React from 'react'
// import './Home.css'
// import Marquee from "react-fast-marquee";




// import { EffectFlip, Pagination, Navigation } from 'swiper/modules';



// const Home = () => {
//     return (
//         <div className="main">
//             <div className='home' >
//                 <div className="image">
//                     <img src="src\assets\skull-with-swords.jpg" alt="" />
//                     <h2 datatype='Car Dealer and Experience'> </h2>
//                     <h3>A car is a vehicle that has wheels, carries a small number <br /> of passengers, and is moved by an engine or a motor.</h3>
//                     <input className='button' type="submit" value=">| Explore Product" />
//                 </div>
//             </div>
//             <div className="information">
//                 <h4>Engine</h4>
//                 <div className="Engine">
//                     <div className="first">
//                         <img src="src\assets\kooggggg.jpg" alt="" />
//                         <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Aperiam asperiores porro, eius praesentium dolor ipsam labore quidem recusandae ea accusantium temporibus iure blanditiis eos in adipisci, obcaecati corrupti sapiente totam accusamus. Tenetur vel a perspiciatis dicta debitis praesentium animi nostrum.</p>
//                     </div>
//                 </div>
//                 <div className="Engine2">

//                     <div className="second">
//                         <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Aperiam asperiores porro, eius praesentium dolor ipsam labore quidem recusandae ea accusantium temporibus iure blanditiis eos in adipisci, obcaecati corrupti sapiente totam accusamus. Tenetur vel a perspiciatis dicta debitis praesentium animi nostrum.</p>
//                         <img src="src\assets\carengine3.jpg" alt="" />
//                     </div>
//                 </div>


//                 <div className='banner'>
//                     <h5>TXT CARS</h5>
//                     <Marquee>

//                         <span> <img src="src\assets\car1.jpg" alt="" /></span>
//                         <span> <img src=" src\assets\car2.jpg" alt="" /></span>
//                         <span> <img src="   src\assets\car3.webp" alt="" /></span>
//                         <span> <img src="src\assets\car4.jpg" alt="" /></span>
//                         <span> <img src="src\assets\car5.webp" alt="" /></span>
//                         <span> <img src="     src\assets\car6.jpg" alt="" /></span>
//                         <span> <img src=" src\assets\car7.jpg" alt="" /></span>
//                         <span> <img src="    src\assets\car8.jpg" alt="" /></span>
//                         <span> <img src="" alt="" /></span>
//                         <span> <img src=" src\assets\car9.jpg" alt="" /></span>

//                     </Marquee>
//                 </div>
//                 <div className="Engine3">
//                     <div className="third">
//                         <img src="src\assets\engine6.jpg" alt="" />
//                         <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Aperiam asperiores porro, eius praesentium dolor ipsam labore quidem recusandae ea accusantium temporibus iure blanditiis eos in adipisci, obcaecati corrupti sapiente totam accusamus. Tenetur vel a perspiciatis dicta debitis praesentium animi nostrum.</p>
//                     </div>
//                 </div>
//                 <div className="Engine4">

//                     <div className="four">
//                         <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Aperiam asperiores porro, eius praesentium dolor ipsam labore quidem recusandae ea accusantium temporibus iure blanditiis eos in adipisci, obcaecati corrupti sapiente totam accusamus. Tenetur vel a perspiciatis dicta debitis praesentium animi nostrum.</p>
//                         <img src="src\assets\engine7.jpg" alt="" />
//                     </div>
//                 </div>
//             </div>
//             <div className='van'>
//                 <h5>TXT RAFA COMPANY </h5>
//                 <h6>HAPPY HOILDAY @TXT RAFA</h6>
//                 <p>car moments and memories are what happy MODIFLY are made of! Travel makes you explore and experience new things, and helps you embark on the journey of self-discovery. So get ready to reward yourself. Allow us to be your gracious host. We promise you unforgettable holidays and memorable experiences. </p>
//                 <div className="container">
//                     <div className="container-first">
//                         <img src="src\assets\audi-logoooo.jpg" alt="errr" />
//                         <img src="src\assets\Rolls logo.jpg" alt="errr" />
//                         <img src="src\assets\Bmw logo.jpg" alt="errr" />
//                         <img src="src\assets\Mercedes logo.jpg" alt="errr" />
//                     </div>
//                     <div className="container-second">
//                         <img src="src\assets\toyota-logo.jpg" alt="errr" />
//                         <img src="src\assets\car logo.jpg" alt="errr" />
//                         <img src="src\assets\hyunai logo.png" alt="errr" />
//                         <img src="src\assets\new tata logo.jpg" alt="errr" />
//                     </div>
//                 </div>
//                 <h4>Newsletter</h4>
//                 <p>Stay up to date with the latest news from the world of TXT☠RAFA.</p>
//                 <div className='bin'>
//                     <button>SUBSCRIBE</button>
//                 </div>
//             </div>
//             <div className="Ace">
//                 <div className="Sabo">
//                     <div className="Luffy">
//                         <div className="col">
//                             <h2 className='ttle'>Racing</h2>
//                             <a href="">  Ferrari Driver Academy </a>
//                             <a href="">Scuderia Ferrari HP</a>
//                             <a href="">Carlos Sainz </a>
//                             <a href="">Charles Leclerc</a>
//                             <a href=""> Hypercar</a>
//                             <a href=""> Esports  </a>
//                             <a href=""> Gtx  </a>

//                         </div>
//                         <div className="col">
//                             <h2 className='ttle'> Sports Cars</h2>
//                             <a href="">  Configure your Ferrari </a>
//                             <a href="">Recall information</a>
//                             <a href="">MyFerrari </a>
//                             <a href="">Pre-owned</a>
//                             <a href="">TechInfo</a>
//                             <a href=""> Dealers  </a>
//                             <a href=""> Range </a>

//                         </div>
//                         <div className="col">
//                             <h2 className='ttle'>       Experiences</h2>
//                             <a href=""> Ferrari World Abu Dhabi </a>
//                             <a href="">Ferrari Land Barcelona</a>
//                             <a href="">Ferrari Esports Series </a>
//                             <a href="">Ristorante Cavallino</a>
//                             <a href="">Ferrari Museums</a>
//                             <a href=""> Corse Clienti </a>
//                             <a href=""> Quality </a>
//                         </div>
//                         <div className="col">
//                             <h2 className='ttle'> NEWSROOM</h2>
//                             <a href=""> Thought leadership</a>
//                             <a href="">Press releases</a>
//                             <a href="">Media library</a>
//                             <a href="">   Overview</a>
//                         </div>
//                         <div className="col">
//                             <h2 className='ttle'>CAREERS</h2>
//                             <a href=""> Openings @ TXT☠RAFA</a>
//                             <a href="">Life @ TXT☠RAFA</a>
//                             <a href="">Overview</a>
//                             <a href="">   FAQs</a>
//                         </div>

//                     </div>
//                 </div>
//                 <div className="nine">
//                     <h2>SOCIAL MEDIA</h2>
//                     <div className="icon">
//                         <span><a href="https://linkedin.com"><i className="fa-brands fa-linkedin"></i></a></span>
//                         <span><a href="https://facebook.com"><i className="fa-brands fa-facebook"></i></a></span>
//                         <span><a href="https://instagram.com" target="_blank"><i className="fa-brands fa-instagram"></i></a></span>
//                         <span><a href="https://x.com"><i class="fa-brands fa-x-twitter"></i></a></span>
//                         <span><a href="https://google.com"><i className="fa-brands fa-google"></i></a></span>
//                         <span><a href="https://telegram.com"><i className="fa-brands fa-telegram"></i></a></span>
//                     </div>

//                 </div>
//             </div>

//         </div >
//     )
// }

// export default Home


































import React, { useEffect } from 'react';
import './Home.css';
import Marquee from "react-fast-marquee";


import { EffectFlip, Pagination, Navigation } from 'swiper/modules';

const Home = () => {
    useEffect(() => {
        const scrollElements = document.querySelectorAll('.scroll-animation');

        const elementInView = (el, dividend = 1) => {
            const elementTop = el.getBoundingClientRect().top;
            return (
                elementTop <= (window.innerHeight || document.documentElement.clientHeight) / dividend
            );
        };

        const displayScrollElement = (element) => {
            element.classList.add('scroll-animation-visible');
        };

        const handleScrollAnimation = () => {
            scrollElements.forEach((el) => {
                if (elementInView(el, 1.25)) {
                    displayScrollElement(el);
                }
            });
        };

        window.addEventListener('scroll', handleScrollAnimation);


        handleScrollAnimation();

        return () => {
            window.removeEventListener('scroll', handleScrollAnimation);
        };
    }, []);

    return (
        <div className="main">
            <div className='home'>
                <div className="image">
                    <img src="src/assets/skull-with-swords.jpg" alt="" />
                    <h2 datatype='Car Dealer and Experience'> </h2>
                    <h3>A car is a vehicle that has wheels, carries a small number <br /> of passengers, and is moved by an engine or a motor.</h3>
                    <input className='button' type="submit" value=">| Explore Product" />
                </div>
            </div>
            <div className="information scroll-animation">
                <h4>Engine</h4>
                <div className="Engine">
                    <div className="first">
                        <img src="src/assets/kooggggg.jpg" alt="" />
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Aperiam asperiores porro, eius praesentium dolor ipsam labore quidem recusandae ea accusantium temporibus iure blanditiis eos in adipisci, obcaecati corrupti sapiente totam accusamus. Tenetur vel a perspiciatis dicta debitis praesentium animi nostrum.</p>
                    </div>
                </div>
                <div className="Engine2 scroll-animation">
                    <div className="second">
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Aperiam asperiores porro, eius praesentium dolor ipsam labore quidem recusandae ea accusantium temporibus iure blanditiis eos in adipisci, obcaecati corrupti sapiente totam accusamus. Tenetur vel a perspiciatis dicta debitis praesentium animi nostrum.</p>
                        <img src="src/assets/carengine3.jpg" alt="" />
                    </div>
                </div>
                <div className='banner scroll-animation'>
                    <h5>TXT CARS</h5>
                    <Marquee>
                        <span><img src="src/assets/car1.jpg" alt="" /></span>
                        <span><img src="src/assets/car2.jpg" alt="" /></span>
                        <span><img src="src/assets/car3.webp" alt="" /></span>
                        <span><img src="src/assets/car4.jpg" alt="" /></span>
                        <span><img src="src/assets/car5.webp" alt="" /></span>
                        <span><img src="src/assets/car6.jpg" alt="" /></span>
                        <span><img src="src/assets/car7.jpg" alt="" /></span>
                        <span><img src="src/assets/car8.jpg" alt="" /></span>
                        <span><img src="src/assets/car9.jpg" alt="" /></span>
                    </Marquee>
                </div>
                <div className="Engine3 scroll-animation">
                    <div className="third">
                        <img src="src/assets/engine6.jpg" alt="" />
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Aperiam asperiores porro, eius praesentium dolor ipsam labore quidem recusandae ea accusantium temporibus iure blanditiis eos in adipisci, obcaecati corrupti sapiente totam accusamus. Tenetur vel a perspiciatis dicta debitis praesentium animi nostrum.</p>
                    </div>
                </div>
                <div className="Engine4 scroll-animation">
                    <div className="four">
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Aperiam asperiores porro, eius praesentium dolor ipsam labore quidem recusandae ea accusantium temporibus iure blanditiis eos in adipisci, obcaecati corrupti sapiente totam accusamus. Tenetur vel a perspiciatis dicta debitis praesentium animi nostrum.</p>
                        <img src="src/assets/engine7.jpg" alt="" />
                    </div>
                </div>
            </div>
            <div className='van scroll-animation'>
                <h5>TXT RAFA COMPANY </h5>
                <h6>HAPPY HOILDAY @TXT RAFA</h6>
                <p>Car moments and memories are what happy MODIFLY are made of! Travel makes you explore and experience new things, and helps you embark on the journey of self-discovery. So get ready to reward yourself. Allow us to be your gracious host. We promise you unforgettable holidays and memorable experiences.</p>
                <div className="container">
                    <div className="container-first">
                        <img src="src/assets/audi-logoooo.jpg" alt="errr" />
                        <img src="src/assets/Rolls logo.jpg" alt="errr" />
                        <img src="src/assets/Bmw logo.jpg" alt="errr" />
                        <img src="src/assets/Mercedes logo.jpg" alt="errr" />
                    </div>
                    <div className="container-second">
                        <img src="src/assets/toyota-logo.jpg" alt="errr" />
                        <img src="src/assets/car logo.jpg" alt="errr" />
                        <img src="src/assets/hyunai logo.png" alt="errr" />
                        <img src="src/assets/new tata logo.jpg" alt="errr" />
                    </div>
                </div>
                <h4>Newsletter</h4>
                <p>Stay up to date with the latest news from the world of TXT☠RAFA.</p>
                <div className='bin'>
                    <button>SUBSCRIBE</button>
                </div>
            </div>
            <div className="Ace scroll-animation">
                <div className="Sabo">
                    <div className="Luffy">
                        <div className="col">
                            <h2 className='ttle'>Racing</h2>
                            <a href="">Ferrari Driver Academy</a>
                            <a href="">Scuderia Ferrari HP</a>
                            <a href="">Carlos Sainz</a>
                            <a href="">Charles Leclerc</a>
                            <a href="">Hypercar</a>
                            <a href="">Esports</a>
                            <a href="">Gtx</a>
                        </div>
                        <div className="col">
                            <h2 className='ttle'>Sports Cars</h2>
                            <a href="">Configure your Ferrari</a>
                            <a href="">Recall information</a>
                            <a href="">MyFerrari</a>
                            <a href="">Pre-owned</a>
                            <a href="">TechInfo</a>
                            <a href="">Dealers</a>
                            <a href="">Range</a>
                        </div>
                        <div className="col">
                            <h2 className='ttle'>Experiences</h2>
                            <a href="">Ferrari World Abu Dhabi</a>
                            <a href="">Ferrari Land Barcelona</a>
                            <a href="">Ferrari Esports Series</a>
                            <a href="">Ristorante Cavallino</a>
                            <a href="">Ferrari Museums</a>
                            <a href="">Corse Clienti</a>
                            <a href="">Quality</a>
                        </div>
                        <div className="col">
                            <h2 className='ttle'>NEWSROOM</h2>
                            <a href="">Thought leadership</a>
                            <a href="">Press releases</a>
                            <a href="">Media library</a>
                            <a href="">Overview</a>
                        </div>
                        <div className="col">
                            <h2 className='ttle'>CAREERS</h2>
                            <a href="">Openings @ TXT☠RAFA</a>
                            <a href="">Life @ TXT☠RAFA</a>
                            <a href="">Overview</a>
                            <a href="">FAQs</a>
                        </div>
                    </div>
                </div>
                <div className="nine scroll-animation">
                    <h2>SOCIAL MEDIA</h2>
                    <div className="icon">
                        <span><a href="https://linkedin.com"><i className="fa-brands fa-linkedin"></i></a></span>
                        <span><a href="https://facebook.com"><i className="fa-brands fa-facebook"></i></a></span>
                        <span><a href="https://instagram.com" target="_blank"><i className="fa-brands fa-instagram"></i></a></span>
                        <span><a href="https://x.com"><i class="fa-brands fa-x-twitter"></i></a></span>
                        <span><a href="https://google.com"><i className="fa-brands fa-google"></i></a></span>
                        <span><a href="https://telegram.com"><i className="fa-brands fa-telegram"></i></a></span>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Home;
