// import React from 'react'
// import './Service.css'


// export const Service = () => {
//   return (
//     <div className="vermithor">
//       <div className='control'>
//         <div className="service-container">
//           <div className='head'>
//             <h2>Professional Services <br /> for Car</h2>
//             <ul>
//               <li>
//                 <h3>Car & Experienced Team of Experts</h3>
//               </li>
//               <li>
//                 <h4>Simple to complex car issues</h4>
//               </li>
//               <li>
//                 <h4>Cost-Efficient Services at your doorstep</h4>
//               </li>

//             </ul>
//           </div>
//           <img src="src\assets\servicesff.png" alt="" />

//         </div>
//       </div >
//       <div className="norway">
//         <h5>Most Utilized Services</h5>
//         <div className="card-container">
//           <div className="card">
//             <img src="src\assets\car wash.avif" alt="" />
//             <h6>Car Wash</h6>
//             <p>Get your car washed with our expert team Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempora error sequi aliquid quos corporis. Cumque sunt sint </p>
//             <a href="" className='bt'>Read More</a>
//           </div>
//           <div className="card ">
//             <img src="src\assets\Car Interior Cleaning.webp" alt="" />
//             <h6> Car Interior Cleaning</h6>
//             <p>Get your car washed with our expert team Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempora error sequi aliquid quos corporis. Cumque sunt sint </p>
//             <a href="" className='bt'>Read More</a>
//           </div>
//           <div className="card">
//             <img src="src\assets\Car Testing drive.jpg" alt="" />
//             <h6>  Car Testing drive </h6>
//             <p>Get your car washed with our expert team Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempora error sequi aliquid quos corporis. Cumque sunt sint </p>
//             <a href="" className='bt'>Read More</a>
//           </div>
//         </div>
//       </div>

//     </div>


//   )
// }
// export default Service
































// Import Swiper React components
import { Swiper, SwiperSlide } from 'swiper/react';

// Import Swiper styles
import 'swiper/css';
import 'swiper/css/free-mode';
import 'swiper/css/pagination';

// import 'swiper/css/navigation';


// import required modules
import { FreeMode, Pagination } from 'swiper/modules';
// import { Model } from './components/Model';
import Modal from 'react-modal';






import React, { useEffect, useRef, useState } from 'react';
import './Service.css';

export const Service = () => {


  const vermithorRef = useRef(null);
  const norwayRef = useRef(null);
  const casRef = useRef(null);

  const [isVermithorVisible, setIsVermithorVisible] = useState(false);
  const [isNorwayVisible, setIsNorwayVisible] = useState(false);
  const [isCasVisible, setIsCasVisible] = useState(false);
  const [modelsIsopen, setmodelsIsopen] = useState(false);

  const customStyles = {
    content: {
      top: '50%',
      left: '50%',
      right: 'auto',
      bottom: 'auto',
      marginRight: '-50%',
      transform: 'translate(-50%, -50%)',

    },
  };

  let subtitle;
  const [modalIsOpen, setIsOpen] = React.useState(false);

  function openModal() {
    setIsOpen(true);
  }

  function afterOpenModal() {
    // references are now sync'd and can be accessed.
    subtitle.style.color = '#f00';
  }

  function closeModal() {
    setIsOpen(false);
  }



  useEffect(() => {
    const observerCallback = (entries, observer) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          if (entry.target === vermithorRef.current) {
            setIsVermithorVisible(true);
          } else if (entry.target === norwayRef.current) {
            setIsNorwayVisible(true);
          } else if (entry.target === casRef.current) {
            setIsCasVisible(true);
          }
          observer.unobserve(entry.target);
        }
      });
    };

    const observerOptions = {
      threshold: 0.1, // Element is considered visible when 10% of it is in view
    };

    const observer = new IntersectionObserver(observerCallback, observerOptions);

    if (vermithorRef.current) observer.observe(vermithorRef.current);
    if (norwayRef.current) observer.observe(norwayRef.current);
    if (casRef.current) observer.observe(casRef.current);
  
    return () => {
      if (vermithorRef.current) observer.unobserve(vermithorRef.current);
      if (norwayRef.current) observer.unobserve(norwayRef.current);
      if (casRef.current) observer.unobserve(casRef.current);
    };
  }, []);

  return (
    <div className="service-page">
      <div
        className={`vermithor ${isVermithorVisible ? 'visible' : ''}`}
        ref={vermithorRef}
      >
        <div className='control'>
          <div className="service-container">
            <div className='head'>
              <h2>Professional Services <br /> for Car</h2>
              <ul>
                <li>
                  <h3>Car & Experienced Team of Experts</h3>
                </li>
                <li>
                  <h4>Simple to complex car issues</h4>
                </li>
                <li>
                  <h4>Cost-Efficient Services at your doorstep</h4>
                </li>
              </ul>
            </div>
            <img src="src/assets/servicesff.png" alt="" />
          </div>
        </div>
      </div>
      <div
        className={`norway ${isNorwayVisible ? 'visible' : ''}`}
        ref={norwayRef}
      >
        <h5>Most Utilized Free Services</h5>
        <div className="card-container">
          <div className="card">
            <img src="src/assets/car wash.avif" alt="" />
            <h6>Car Wash</h6>
            <p>
              Get your car washed with our expert team Lorem ipsum dolor sit
              amet consectetur adipisicing elit. Tempora error sequi aliquid
              quos corporis. Cumque sunt sint{' '}
            </p>
            <a href="#" className='bt'>Read More</a>
          </div>
          <div className="card">
            <img src="src/assets/Car Interior Cleaning.webp" alt="" />
            <h6> Car Interior Cleaning</h6>
            <p>
              Get your car washed with our expert team Lorem ipsum dolor sit
              amet consectetur adipisicing elit. Tempora error sequi aliquid
              quos corporis. Cumque sunt sint{' '}
            </p>
            <a href="#" className='bt'>Read More</a>
          </div>
          <div className="card">
            <img src="src/assets/Car Testing drive.jpg" alt="" />
            <h6> Car Testing drive </h6>
            <p>
              Get your car washed with our expert team Lorem ipsum dolor sit
              amet consectetur adipisicing elit. Tempora error sequi aliquid
              quos corporis. Cumque sunt sint{' '}
            </p>
            <a href="#" className='bt'>Read More</a>
          </div>
        </div>
      </div>

      <div
        className={`cas ${isCasVisible ? 'visible' : ''}`}
        ref={casRef}
      >
        <div className="cas">
          <h5>Most Utilized Free Services</h5>
          <div class="kan">
            <div className="car-image-container">
              <img src="src\assets\demo car.png" alt="" className='car-image' />
              <div className="dot" style={{ top: "35%", left: "25%" }} title='dent paint' data-description='adffffffffffffffffffffffffffffffffffffffffffff' > </div>
              <div className="dot" style={{ top: "43%", left: "12%" }} title='Oil / Lube / Filters'> </div>
              <div className="dot" style={{ top: "40%", left: "32.5%" }} title='Diagnostics'></div>
              <div className="dot" style={{ top: "45%", left: "60%" }} title='Detailing'></div>
              <div className="dot" style={{ bottom: "50%", left: "77%" }} title='Suspension'></div>
              <div className="dot" style={{ top: "70%", left: "76.5%" }} title='Brakes'></div>
            </div>
          </div>

          <div className="Govish">
            <div className="image-container">
              <img src="src/assets/dot6.jpeg" alt="Image 6" />
              <div className="overlay"><span>  Detailing</span> <p>
                AutoMechanica offers professional car detail services at an affordable price. Our interior cleaning, detailing, and restoration services can help you recapture that new car look and smell.
              </p></div>
            </div>
            <div className="image-container">
              <img src="src/assets/dot1.jpeg" alt="Image 1" />
              <div className="overlay"> <span> Brakes</span><p>The brake system consists of different parts that can be fixed individually. A detailed quote is given to you after we perform our systematic brake evaluation.</p></div>
            </div>
            <div className="image-container">
              <img src="src/assets/dot2.jpeg" alt="Image 2" />
              <div className="overlay"><span>Dent & Paint</span><p>AutoMechanica specializes in car dent repair and car painting services for a range of models.</p></div>
            </div>
            <div className="image-container">
              <img src="src/assets/dot3.jpeg" alt="Image 3" />
              <div className="overlay"> <span>
                Diagnostics</span><p>If your car needs a mobile diagnostic check done at your home or office, let AutoMechanica come to you.</p></div>
            </div>
            <div className="image-container">
              <img src="src/assets/dot5.jpeg" alt="Image 5" />
              <div className="overlay"><span>Suspension </span><p>The suspension system of your vehicle protects you from bouncing up and down due to the bad road conditions and bumps in the road.</p></div>
            </div>
            <div className="image-container">
              <img src="src/assets/dot4.jpeg" alt="Image 4" />
              <div className="overlay"><span>Oil/Lube/Filters</span> <p>AutoMechanica proudly serves the Lube, Oil & Filter change needs of customers' vehicle performance while extending the life of your vehicle.</p></div>
            </div>

          </div>

        </div>
      </div>
      <div className="slider">
        <h4>Best Engineering Service </h4>
        <div className="slider-container">
          <Swiper
            slidesPerView={3}
            spaceBetween={30}
            freeMode={true}
            pagination={{
              clickable: true,
            }}
            modules={[FreeMode, Pagination]}
            className="mySwiper"
          >
            <SwiperSlide><div className="oak">
              <img src="src\assets\zoro.jpg" alt="" />
              <div className="you">
                <h6>Zoro</h6>
                <p>
                  Get your car washed with our expert team Lorem ipsum dolor sit
                  amet consectetur adipisicing elit. Tempora error sequi aliquid
                  quos corporis. Cumque sunt sint{' '}
                </p>
                <a href="#" className='wick'>Read More</a>
              </div>
            </div></SwiperSlide>
            <SwiperSlide><div className="oak">
              <img src="src\assets\sanji.jpg" alt="" />
              <div className="you">
                <h6>Sanji</h6>
                <p>
                  Get your car washed with our expert team Lorem ipsum dolor sit
                  amet consectetur adipisicing elit. Tempora error sequi aliquid
                  quos corporis. Cumque sunt sint{' '}
                </p>
                <a href="#" className='wick'>Read More</a>
              </div>
            </div></SwiperSlide>
            <SwiperSlide><div className="oak">
              <img src="src\assets\ggg.jpg" alt="" />
              <div className="you">
                <h6>Sukuna</h6>
                <p>
                  Get your car washed with our expert team Lorem ipsum dolor sit
                  amet consectetur adipisicing elit. Tempora error sequi aliquid
                  quos corporis. Cumque sunt sint{' '}
                </p>
                <a href="#" className='wick'>Read More</a>
              </div>
            </div></SwiperSlide>
            <SwiperSlide><div className="oak">
              <img src="src\assets\ffff.jpg" alt="" />
              <div className="you">
                <h6>kakashi</h6>
                <p>
                  Get your car washed with our expert team Lorem ipsum dolor sit
                  amet consectetur adipisicing elit. Tempora error sequi aliquid
                  quos corporis. Cumque sunt sint{' '}
                </p>
                <a href="#" className='wick'>Read More</a>
              </div>
            </div></SwiperSlide>
            <SwiperSlide><div className="oak">
              <img src="src\assets\levitttt.jpg" alt="" />
              <div className="you">
                <h6>Levi</h6>
                <p>
                  Get your car washed with our expert team Lorem ipsum dolor sit
                  amet consectetur adipisicing elit. Tempora error sequi aliquid
                  quos corporis. Cumque sunt sint{' '}
                </p>
                <a href="#" className='wick'>Read More</a>
              </div>
            </div></SwiperSlide>
            <SwiperSlide><div className="oak">
              <img src="src\assets\Ryoh_Grantz_777.jpg" alt="" />
              <div className="you">
                <h6>Ryu</h6>
                <p>
                  Get your car washed with our expert team Lorem ipsum dolor sit
                  amet consectetur adipisicing elit. Tempora error sequi aliquid
                  quos corporis. Cumque sunt sint{' '}
                </p>
                <a href="#" className='wick'>Read More</a>
              </div>
            </div></SwiperSlide>
            <SwiperSlide>

              <div className="oak">
                <img src="src\assets\ncs.png" alt="" />
                <div className="you">
                  <h6>Luffy</h6>
                  <p>
                    Get your car washed with our expert team Lorem ipsum dolor sit
                    amet consectetur adipisicing elit. Tempora error sequi aliquid
                    quos corporis. Cumque sunt sint{' '}
                  </p>
                  <a href="#" className='wick'>Read More</a>
                </div>
              </div>

            </SwiperSlide>
          </Swiper>
        </div>
      </div>
      <div className="vermax">
        <h3>How It Works</h3>
        <h4>Book Car Service online in 3 simple steps</h4>
        <div className="payment">

          <div className="hok">
            <img src="src/assets/repair.jpg" alt="Select Services" />
            <div className="lor">
              <h5>Select Desired Services</h5>
            </div>
          </div>
          <span><i class="fas fa-long-arrow-alt-right    "></i></span>

          <div className="hok">
            <img src="src\assets\calendar.avif" alt="Select Services" />
            <div className="lor">
              <h5>Choose Date & Time</h5>
            </div>
          </div>
          <span><i class="fas fa-long-arrow-alt-right    "></i></span>
          <div className="hok">
            <img src="src\assets\payment.png" alt="Select Services" />
            <div className="lor">
              <h5>Select Payment Option</h5>
            </div>
          </div>
        </div>
        <div className='model'>
          <button onClick={openModal}>Open Modal</button>
          <Modal
            isOpen={modalIsOpen}
            onAfterOpen={afterOpenModal}
            onRequestClose={closeModal}
            style={customStyles}
            contentLabel="Login Modal"
          >

            <div className='goha'>
              <button onClick={closeModal}>✕</button>
              <div className="div">
                <h2>GET FREE QUOTATION FOR YOUR CAR</h2>
                <h3>Fill in your details below to request a call back</h3>
                {/* <button onClick={closeModal}>✖</button> */}
              </div>
              {/* <button onClick={closeModal}>✖</button> */}

              <div className='chandel'>
                <div className="sage">
                  <img src="src\assets\banner.png" alt="" />
                  <br />
                  <img src="src\assets\sample.jpeg" alt="" />
                </div>


                <div className='Govishs'>
                  <div className="login">
                    <label htmlFor="Name">Name</label>
                    <input type="text" id="Name" name="Name" placeholder='Name' />
                  </div>

                  <div className="login">
                    <label htmlFor="Phone">Phone</label>
                    <div className="phone-input">
                      <select id="country-code">
                        <option value="+1">🇺🇸 +1 (United States) </option>
                        <option value="+1">🇨🇦 +1 (Canada)</option>
                        <option value="+44">🇬🇧 +44 (United Kingdom)</option>
                        <option value="+91">🇮🇳  +91 (India)</option>
                      </select>
                      <input type="tel" id="Phone" name="Phone" placeholder="Phone number" />
                    </div>
                  </div>

                  <div className="login">
                    <label htmlFor="Content">What are you looking for? (Optional)</label>
                    <select class="form-select" fdprocessedid="ck1141">

                      <optio>Click to select </optio>

                      <option value="car-wash">Car Wash</option>

                      <option value="insurance">Car Insurance</option>

                      <option value="workshop">Garage / Workshop</option>

                      <option value="parts">Car Parts</option>

                      <option value="others">Other</option>

                    </select>
                  </div>

                </div>

              </div>
              <div className='call'>
                <button > <i class="fa-solid fa-phone"></i>Request A Call Back</button>
              </div>

            </div>

          </Modal>
        </div>
      </div>
      <div className="gallery">
        <div className="row">
          <div className="column">
            <a href="src\assets\jack1.jpg" rel="magnific" className="inited">
              <img src="src\assets\jack1.jpg" alt="Image 1" className="hover-shadow cursor" />
            </a>
          </div>
          <div className="column">
            <a href="src\assets\jack2.png" rel="magnific" className="inited">
              <img src="src\assets\jack2.png" alt="Image 2" className="hover-shadow cursor" />
            </a>
          </div>
          <div className="column">
            <a href="src\assets\wash3.webp" rel="magnific" className="inited">
              <img src="src\assets\wash3.webp" alt="Image 3" className="hover-shadow cursor" />
            </a>
          </div>
          <div className="column">
            <a href="src\assets\wash3.webp" rel="magnific" className="inited">
              <img src="src\assets\wash3.webp" alt="Image 3" className="hover-shadow cursor" />
            </a>
          </div>
          <div className="column">
            <a href="src\assets\wash3.webp" rel="magnific" className="inited">
              <img src="src\assets\wash3.webp" alt="Image 3" className="hover-shadow cursor" />
            </a>
          </div>
        </div>
      </div>


    </div>
  );

};

export default Service;
