/*import { useSelector, useDispatch } from "react-redux";
import React, { useEffect, useState } from "react";
import './Login.css';
import { Link, useNavigate } from "react-router-dom";
import { login } from "../../redux/actions/userAction"; // Corrected path
import toast from "react-hot-toast";
import img from "../assets/login.png"; // Ensure this path is correct

const Login = () => {
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });
  const { loading, error, message } = useSelector((state) => state.user);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    await dispatch(login(formData));
    navigate("/profile");
  };

  useEffect(() => {
    if (error) {
      toast.error(error);
      dispatch({ type: "clearErrors" });
    }
    if (message) {
      toast.success(message);
      dispatch({ type: "clearMessage" });
    }
  }, [error, message, dispatch]);

  return (
    <div>
      <div className="header">
        <h1> Login</h1>
        <span>
          <Link to="/">Home</Link> <small>&#8250;</small> Login
        </span>
      </div>
      <div className="login">
        <div className="login-intro">
          <h2>Login</h2>
          <img src={img} alt="login" />
        </div>
        <form onSubmit={handleSubmit} className="login-form">
          <input
            type="email"
            name="email"
            placeholder="Email"
            value={formData.email}
            onChange={handleChange}
          />
          <input
            type="password"
            name="password"
            placeholder="Password"
            value={formData.password}
            onChange={handleChange}
          />
          <button disabled={loading} type="submit" className="btn-primary">
            {loading ? "Loading..." : "Login"}
          </button>
          <div className="login-action">
            <p>
              Not a member?
              <Link to="/signup" className="signup-link">
                {" "}
                SignUp{" "}
              </Link>
              here
            </p>
            <p>
              <Link to="/forgetpassword" className="forgot-password-btn">
                Forgot Password?
              </Link>
            </p>
          </div>
        </form>
      </div>
    </div>
  );
};

// export default Login;*/




<div className="container">
                    <div className="container-first">
                        <img src="src\assets\audi-logoooo.jpg" alt="errr" />
                        <img src="src\assets\Rolls logo.jpg" alt="errr" />
                        <img src="src\assets\Bmw logo.jpg" alt="errr" />
                        <img src="src\assets\Mercedes logo.jpg" alt="errr" />
                    </div>
                    <div className="container-second">
                        <img src="src\assets\toyota-logo.jpg" alt="errr" />
                        <img src="src\assets\car logo.jpg" alt="errr" />
                        <img src="src\assets\hyunai logo.png" alt="errr" />
                        <img src="src\assets\new tata logo.jpg" alt="errr" />
                    </div>
                </div>



// .home {
//   width: 98.2%;
//   height: 100%;
//   padding: 0.5rem 1rem;
//   display: flex;
//   justify-content: end;
//   /* Center content horizontally */
//   align-items: center;
//   background-color: rgb(255, 255, 255);
// }

// .image {
//   justify-content: end;
//   align-items: center;
//   display: flex;
// }
// .image h2{
//   font-size: 3rem;
//   /* padding: 1rem 4rem; */
//   margin: auto;
//   /* margin: 9rem; */
//   padding-right: 22rem;
// }

// .image img{
//   width: 55rem;
//   height: 35rem;
//   padding-top: 9rem;
//   align-items: center;
// }

/* @media (max-width: 633px){
/* .home{
    width: 100rem;
} */
/* }  */

/* Medium devices (tablets, 768px and up) */
/* @media (max-width: 720px) {
  .home {
    width: 60rem;
    background-size: cover;
    background-position: center;
  }

  .image h2 {
    font-size: 2.5rem;
  }

  .image h3 {
    font-size: 1.2rem;
  }

  .image img {
    height: 180px;
    width: 180px;
  }

  .button {
    padding: 0.5rem 1.8rem;
    font-size: 0.9rem;
  }
} */

/* Large devices (desktops, 992px and up) */
/* @media (max-width: 992px) {
  .image h2 {
    font-size: 2.8rem;
    background-size: cover;
    background-position: center;
  }

  .image h3 {
    font-size: 1.3rem;
  }

  .image img {
    height: 190px;
    width: 190px;
  }

  .button {
    padding: 0.55rem 1.9rem;
    font-size: 0.95rem;
  }
} */

/* Extra large devices (large desktops, 1200px and up) */
/* @media (max-width: 1200px) { */
  /* .home{ */
  /* width: 10em; */
  /* } */
  /* .image h2 {
    font-size: 3rem;
  }

  .image h3 {
    font-size: 1.4rem;
  }

  .image img {
    height: 200px;
    width: 200px;
  }

  .button {
    padding: 0.6rem 2rem;
    font-size: 1rem;
  }
} */

/* *********Tab******* */
/* @media only screen and (min-width: 768px) and (max-width: 991px) {
} */

/* ********Mobile********* */
/* @media only screen and (min-width: 320px) and (max-width: 767px) {
} */
/* small devices (tablets, 576px and up) */
/* @media (max-width: 570px) {
  .home {
    width: 250%;
    background-size: cover;
    background-position: center;
  }

  .image h2 {
    font-size: 2rem;
  }

  .image h3 {
    font-size: 1rem;
    font-size: 1rem;
  }

  .image img {
    height: 150px;
    width: 150px;
  }

  .button {
    padding: 0.4rem 1.5rem;
    font-size: 0.8rem;
  }
} */


  /* General Container Styles */
.control {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 2rem;
  background: linear-gradient( rgba(0, 0, 0, 0.7),rgba(255, 255, 255, 0.7));
  height: 90vh;
}

/* Service Container */
.service-container {
  width: 100%;
  max-width: 1200px;
  background-color: #d3d3d3;
  border-radius: 12px;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 2rem;
  margin-bottom: 2rem;
  flex-wrap: wrap;
  opacity: 0; /* Initially hidden */
  transform: translateY(50px); /* Start position for animation */
  transition: all 0.6s ease-in-out;
}

.vermithor.visible .service-container {
  opacity: 1; /* Fade in */
  transform: translateY(0); /* Slide to the original position */
}
/* Image Styling */
.service-container img {
  width: 50%;
  border-radius: 12px;
  object-fit: cover;
  filter: saturate(8);
}

.head {
  flex: 1;
  padding: 2rem;
  color: #333;
}

.head h2 {
  font-size: 2.9rem;
  margin-bottom: 1.5rem;
  color: #2c3e50;
  font-weight: bold;
  line-height: 1.2;
}

.head ul {
  list-style-type: disc;
  padding-left: 1.5rem;
}

.head ul li {
  font-size: 1.3rem;
  margin-bottom: 1rem;
  color: #555;
}

/* Responsive Design */
@media (max-width: 1024px) {
  .service-container {
    flex-direction: column;
    align-items: center;
    text-align: center;
  }

  .service-container img {
    width: 100%;
    margin-bottom: 1rem; /* Add margin for spacing */
  }

  .head {
    padding: 1rem;
  }

  .head h2 {
    font-size: 2.5rem;
  }

  .head ul li {
    font-size: 1.2rem;
  }
}

@media (max-width: 768px) {
  .head h2 {
    font-size: 2rem;
  }

  .head ul li {
    font-size: 1.1rem;
  }
}

@media (max-width: 480px) {
  .service-container {
    padding: 1rem;
  }

  .head h2 {
    font-size: 1.8rem;
  }

  .head ul li {
    font-size: 1rem;
  }
}

/* Norway Section */
.norway {
  background-color: #f5f5f5;
  padding: 1rem 2rem; 
  border-radius: 8px; 
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  margin-bottom: 1.5rem;
  opacity: 0; /* Initially hidden */
  transform: translateY(50px); /* Start position for animation */
  transition: all 0.6s ease-in-out;
}

.norway.visible {
  opacity: 1; /* Fade in */
  transform: translateY(0); /* Slide to the original position */
}
.norway h5 {
  font-size: 1.8rem;
  color: #2c3e50; 
  margin: 0; 
  font-weight: bold; 
  text-align: center;
}

.card-container{
  display: flex;
  justify-content: center;
  flex-wrap: wrap;
  margin-top:4rem;
  gap: 8rem;
}
.card{
  width: 325px;
  background-color: #f0f0f0;
  border-radius: 1rem;
  overflow: hidden;
  box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.2);
  margin: 20px;
}

.card img{
  width: 100%;
  height: auto;
}
.card-content{
  padding: 2rem;
}
.card h6{
  font-size: 1.5rem;
  margin-bottom: 8px;
  padding: 0.5rem 8px;
}
.card p{
  color: rgb(53, 42, 29);
  font-size: 1.3rem;
  line-height: 1.3;
  padding: 0rem 1rem;
}

.bt{
display: inline-block;
padding: 8px 16px;
background-color: rgb(255, 145, 0);
text-decoration: none;
border-radius: 4px;
margin-top: 16px;
color: aqua;
} 

/* Rest of your styles */

