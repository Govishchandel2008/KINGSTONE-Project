//import React, { useState } from 'react';
// import { Link } from 'react-router-dom';
// import "./Navbar.css";

// const Navbar = () => {
/*const [active, setActive] = useState(false);
const [searchTerm, setSearchTerm] = useState('');

const handleSearch = (e) => {
  e.preventDefault();
  // Add your search logic here
  console.log(`Searching for: ${searchTerm}`);
// };

//return (
  /*<nav>
    <a href="/"><h1>Winter is Coming</h1></a>
    <li>
        <form onSubmit={handleSearch}>
          <div className="search-bar">
            <input
              type="search"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search..."
              className="search-input"
            />
            <button type="submit" className="search-button">
              <i className="fas fa-search search-icon"></i>
            </button>
          </div>
        </form>
      </li>
    <menu className={`${active? 'active' : ''}`}>
      <li>
        <Link to={"/home"} >Home</Link>
      </li>
      <li>
        <Link to={"/project"} >Project</Link>
      </li>
      <li>
        <Link to={"/service"} >Service</Link>
      </li>
      <li>
        <Link to={"/about"} >About</Link>
      </li>
      <li>
        <Link to={"/contact"} >Contact</Link>
      </li>
    </menu>
    <button className='btn'>Signup</button>
    <div className='hamburger' onClick={() => setActive(!active) }></div>
  // { </nav> */
// );
// };

// export default Navbar;

{/* <form>
  <div className="form-group">
    <label htmlFor="username">Username:</label>
    <input type="text" id="username" name="username" />
  </div>

  <div className="form-group">
    <label htmlFor="password">Password:</label>
    <input type="password" id="password" name="password" />
  </div>

  <button type="submit">Login</button>
</form>

 */}








<div>

  <label class="form-label">What are you looking for? (Optional)</label>

  <select class="form-select" fdprocessedid="ck1141">

    <option>Click to select</option>

    <option value="car-wash">Car Wash</option>

    <option value="insurance">Car Insurance</option>

    <option value="workshop">Garage / Workshop</option>

    <option value="parts">Car Parts</option>

    <option value="others">Other</option>

  </select>

</div>